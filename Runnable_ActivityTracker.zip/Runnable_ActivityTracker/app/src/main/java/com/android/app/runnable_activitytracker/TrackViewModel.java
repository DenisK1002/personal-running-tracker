package com.android.app.runnable_activitytracker;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.android.app.runnable_activitytracker.db.Track;
import com.android.app.runnable_activitytracker.db.TrackRepository;

import java.util.List;

public class TrackViewModel extends AndroidViewModel {

    private TrackRepository trackRepository;
    public static LiveData<List<Track>> allTracks;
    public static LiveData<List<Track>> recentTracks;

    public TrackViewModel(@NonNull Application application) {
        super(application);
        trackRepository = new TrackRepository(application);
        allTracks = trackRepository.getAllTracks();
        recentTracks = trackRepository.getRecentTracks();
    }

    public void insert(Track track) {
        trackRepository.insert(track);
    }

    public void delete(Track track) {trackRepository.deleteTrack(track);}

    public LiveData<List<Track>> getAllTracks() {
        return allTracks;
    }

    public LiveData<List<Track>> getRecentTracks() {
        return recentTracks;
    }

}
