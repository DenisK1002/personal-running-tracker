package com.android.app.runnable_activitytracker.db;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.ArrayList;
import java.util.List;

public class TrackRepository {
    private TrackDao trackDao;
    private LiveData<List<Track>> allTracks;
    private LiveData<List<Track>> recentTracks;

    public TrackRepository(Application application) {
        TrackDatabase database = TrackDatabase.getInstance(application);
        trackDao = database.trackDao();
        allTracks = trackDao.getAllTracks();
        recentTracks = trackDao.getRecentTracks();
    }

    public void insert(Track track) {
        new InsertTrackAsyncTask(trackDao).execute(track);
    }

    public void deleteTrack(Track track) {
        new DeleteTrackAsyncTask(trackDao).execute(track);
    }

    public LiveData<List<Track>> getAllTracks() {
        return allTracks;
    }

    public LiveData<List<Track>> getRecentTracks() {
        return recentTracks;
    }

    private static class InsertTrackAsyncTask extends AsyncTask<Track, Void, Void> {

        private TrackDao trackDao;

        public InsertTrackAsyncTask(TrackDao trackDao) {
            this.trackDao = trackDao;
        }

        @Override
        protected Void doInBackground(Track... tracks) {
            trackDao.insert(tracks[0]);
            return null;
        }
    }

    private static class DeleteTrackAsyncTask extends AsyncTask<Track, Void, Void> {

        private TrackDao trackDao;

        public DeleteTrackAsyncTask(TrackDao trackDao) {
            this.trackDao = trackDao;
        }

        @Override
        protected Void doInBackground(Track... tracks) {
            trackDao.delete(tracks[0]);
            return null;
        }
    }
}
